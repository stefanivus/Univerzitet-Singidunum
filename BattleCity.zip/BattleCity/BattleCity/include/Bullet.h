#ifndef BULLET_H
#define BULLET_H

#include <cstdlib>
#include <ctime>
#include "../AnimatedSprite.h"
#include "../Level.h"
#include "Tank.h"

class Bullet : public AnimatedSprite
{
    public:
        Bullet(moveState dir, int x, int y, TankType Shooter, SDL_Renderer *renderer);
        virtual void draw(SDL_Renderer * const renderer);
        virtual void move(int dx,int dy);
        virtual vector<int> getPos();
        virtual vector<int> unit_collision(vector<vector<Tile*> > tiles);
        virtual bool hit_tank(int y, int x,TankType tank);
        virtual int getCountdown();
        virtual void destroy();
        virtual ~Bullet();

    protected:
        moveState direction = MoveUp;
        int countdown = 3;
        TankType shooter;

    private:
};

#endif // BULLET_H
