#ifndef TANK_H
#define TANK_H

#include <cstdlib>
#include <ctime>
#include "../AnimatedSprite.h"
#include "../Level.h"
#include <string>
#include <cmath>
enum TankType{Player, AI1, AI2, AI3, AI4};


class Tank : public AnimatedSprite
{
    public:
        Tank(TankType tip, string url,SDL_Renderer *renderer);
        virtual void draw(SDL_Renderer * const renderer);
        virtual void move(int dx, int dy,vector<vector<Tile*> > tiles);
        void setCurrentState(moveState state);
        virtual void shoot();
        virtual bool unit_collision(vector<vector<Tile*> > tiles);
        virtual moveState getCurrentState();
        virtual TankType getType();
        virtual vector<int> getPos();
        virtual int getHealth();
        virtual bool has_shot();
        virtual void damage();
        virtual void shield();
        virtual void AI_think(vector<vector<Tile*> > tiles,vector<int> playerPos);
        virtual ~Tank();

    protected:
        int row = 0;
        int shot_cooldown = 0;
        int health = 3;
        bool shot = false;
        TankType tip;
        moveState currentState;

    private:
};

#endif // TANK_H
