#include "../include/Tank.h"

Tank::Tank(TankType topos, string url, SDL_Renderer *renderer) : AnimatedSprite(url, 33, 33, 3, renderer)
{
    srand(time(NULL));
    tip = topos;
    if(topos == Player)
    {
       AnimatedSprite::move(400, 150);
    }
    else if(topos == AI1)
    {
       AnimatedSprite::move(650, 100);
    }
    else if(topos == AI2)
    {
       AnimatedSprite::move(50, 550);
    }
    else if(topos == AI3)
    {
       AnimatedSprite::move(720, 550);
    }
    else if(topos == AI4)
    {
       AnimatedSprite::move(50, 70);
    }

}

void Tank::draw(SDL_Renderer * const renderer)
{
    AnimatedSprite::draw(renderer);
    currentRow = 0;
}
void Tank::move(int dx, int dy,vector<vector<Tile*> > tiles)
{
    if(currentState == MoveLeft)
    {
        if(!unit_collision(tiles))
        {
            AnimatedSprite::move(dx, dy);
        }
        currentRow = 1;
    }
    else if(currentState == MoveRight)
    {
        if(!unit_collision(tiles))
        {
            AnimatedSprite::move(dx, dy);
        }
        currentRow = 3;
    }
    else if(currentState == MoveUp)
    {
        if(!unit_collision(tiles))
        {
            AnimatedSprite::move(dx, dy);
        }
        currentRow = 0;
    }
    else if(currentState == MoveDown)
    {
        if(!unit_collision(tiles))
        {
            AnimatedSprite::move(dx, dy);
        }
        currentRow = 2;
    }
    else if(currentState == Stay)
    {
        currentRow--;
    }
}
void Tank::setCurrentState(moveState state)
{
    if(state == MoveUp)
    {
        currentState = MoveUp;
        currentRow = 0;
    }
    else if(state == MoveDown)
    {
        currentState = MoveDown;
        currentRow = 2;
    }
    else if(state == MoveLeft)
    {
        currentState = MoveLeft;
        currentRow = 1;
    }
    else if(state == MoveRight)
    {
        currentState = MoveRight;
        currentRow = 3;
    }
    else if(state == Stay)
    {
        currentState = Stay;
    }
}
void Tank::shoot()
{
    shot = true;
}
moveState Tank::getCurrentState()
{
    return currentState;
}
bool Tank::unit_collision(vector<vector<Tile*> > tiles)
{
    vector<int> pos = getPos();
    int width = (int) ((pos[0]) / (40));
    int height = (int) ((pos[1])/ (40));
    //cout << width << " " << height << endl;
    if(currentState == MoveRight)
    {
        if (tiles[height][width+1]->first != 'b')
        {
            return true;
        }
       else if (tiles[height+1][width+1]->first != 'b')
        {
            if((double) pos[1]/40 - height > (double) 1/4)
            {
                return true;
            }
        }
    }
    else if(currentState == MoveLeft)
    {
        if (tiles[height][width]->first != 'b')
        {
            return true;
        }
       else if (tiles[height+1][width]->first != 'b')
        {
            if((double) pos[1]/40 - height > (double) 1/4)
            {
                return true;
            }
        }
    }
    else if(currentState == MoveUp)
    {
        if (tiles[height][width]->first != 'b')
        {
            return true;
        }
       else if (tiles[height][width+1]->first != 'b')
        {
            if((double) pos[0]/40 - width > (double) 1/4)
            {
                return true;
            }
        }
    }
    else if(currentState == MoveDown)
    {
       if (tiles[height+1][width]->first != 'b')
        {
            return true;
        }
        else if (tiles[height+1][width+1]->first != 'b')
        {
            if((double) pos[0]/40 - width > (double) 1/4)
            {
                return true;
            }
        }
    }

    return false;
}
bool Tank::has_shot()
{
    if(shot)
    {
        shot = false;
        return true;
    }
    return false;
}

void Tank::damage()
{
    health--;
}

void Tank::shield()
{
    health++;
}

vector<int> Tank::getPos()
{
    vector<int> a;
    a.push_back(spriteRect.x);
    a.push_back(spriteRect.y);
    return a;
}

int Tank::getHealth()
{
    return health;
}

TankType Tank::getType()
{
    return tip;
}

void Tank::AI_think(vector<vector<Tile*> > tiles,vector<int> playerPos)
{
    if(tip == AI1)
    {
        if(currentState == MoveLeft)
        {
            move(-1,0,tiles);
        }
        else if(currentState == MoveRight)
        {
            move(1,0,tiles);
        }
        else if(currentState == MoveUp)
        {
            move(0,-1,tiles);
        }
        else if(currentState == MoveDown)
        {
            move(0,1,tiles);
        }
        int chance = rand() % 1000 + 1;
        if (chance < 10)
        {
            chance = rand() % 100 + 1;
            if(chance < 25)
            {
                currentState = MoveLeft;
            }
            else if(chance < 50)
            {
                currentState = MoveRight;
            }
            else if(chance < 75)
            {
                currentState = MoveUp;
            }
            else
            {
                currentState = MoveDown;
            }
        }
        chance = rand() % 1000 + 1;
        if(chance < 10)
        {
            shoot();
        }
    }
    else if(tip == AI2)
    {
        bool check = true;
        setCurrentState(Stay);
        if(shot_cooldown == 0)
        {
            vector<int> pos = getPos();
            if(abs(playerPos[0]-pos[0]) < 30)
            {
                if(playerPos[1] >= pos[1])
                {
                    setCurrentState(MoveDown);
                    for(int j = (int)(pos[1]/40); j < (int)(playerPos[1]/40);j++)
                    {
                        if(tiles[j][(int)(playerPos[0]/40)]->first != 'b')
                        {
                            check = false;
                            break;
                        }
                    }
                }
                else if(playerPos[1] < pos[1])
                {

                    setCurrentState(MoveUp);
                    for(int j = (int)(pos[1]/40); j > (int)(playerPos[1]/40);j--)
                    {
                        if(tiles[j][(int)(playerPos[0]/40)]->first != 'b')
                        {
                            check = false;
                            break;
                        }
                    }
                }
                if(check)
                {
                   shoot();
                }
                shot_cooldown = 100;
            }
            else if(abs(playerPos[1]-pos[1]) < 30)
            {
                if(playerPos[0] >= pos[0])
                {
                    setCurrentState(MoveRight);
                    for(int j = (int)(pos[0]/40); j < (int)(playerPos[0]/40);j++)
                    {
                        if(tiles[(int)(playerPos[1]/40)][j]->first != 'b')
                        {
                            check = false;
                        }
                    }
                }
                else if(playerPos[0] < pos[0])
                {
                    setCurrentState(MoveLeft);
                    for(int j = (int)(pos[0]/40); j > (int)(playerPos[0]/40);j--)
                    {
                        if(tiles[(int)(playerPos[1]/40)][j]->first != 'b')
                        {
                            check = false;
                        }
                    }
                }
                if(check)
                {
                   shoot();
                }
                shot_cooldown = 100;
            }
        }
        else
        {
            shot_cooldown--;
        }
    }
    else if(tip == AI3)
    {
        vector<int> pos = getPos();
        int r = sqrt(pow(pos[0]-playerPos[0],2)+pow(pos[1]-playerPos[1],2));
        if(r < 300)
        {
            if(playerPos[1] >= pos[1])
            {
                setCurrentState(MoveDown);
                move(0,1,tiles);
            }
            else if(playerPos[1] < pos[1])
            {
                setCurrentState(MoveUp);
                move(0,-1,tiles);
            }
            if(playerPos[0] >= pos[0])
            {
                setCurrentState(MoveRight);
                move(1,0,tiles);
            }
            else if(playerPos[0] < pos[0])
            {
                setCurrentState(MoveLeft);
                move(-1,0,tiles);
            }
        }
        if(shot_cooldown == 0)
        {
            if(abs(playerPos[0]-pos[0]) < 30)
            {
                if(playerPos[1] >= pos[1])
                {
                    setCurrentState(MoveDown);
                }
                else if(playerPos[1] < pos[1])
                {
                    setCurrentState(MoveUp);
                }
                shoot();
                shot_cooldown = 100;
            }
            else if(abs(playerPos[1]-pos[1]) < 30)
            {
                if(playerPos[0] >= pos[0])
                {
                    setCurrentState(MoveRight);
                }
                else if(playerPos[0] < pos[0])
                {
                    setCurrentState(MoveLeft);
                }
                shoot();
                shot_cooldown = 100;
            }
        }
        else
        {
            shot_cooldown--;
        }
    }
    else if(tip == AI4)
    {
        vector<int> pos = getPos();


        if(shot_cooldown == 0)
        {
            if(abs(playerPos[0]-pos[0]) < 30)
            {
                if(playerPos[1] >= pos[1])
                {
                    setCurrentState(MoveDown);
                }
                else if(playerPos[1] < pos[1])
                {
                    setCurrentState(MoveUp);
                }
                shoot();
                shot_cooldown = 100;
            }
            else if(abs(playerPos[1]-pos[1]) < 30)
            {
                if(playerPos[0] >= pos[0])
                {
                    setCurrentState(MoveRight);
                }
                else if(playerPos[0] < pos[0])
                {
                    setCurrentState(MoveLeft);
                }
                shoot();
                shot_cooldown = 100;
            }
        }
        else
        {
            shot_cooldown--;
        }
    }
}

Tank::~Tank()
{
    //dtor
}
