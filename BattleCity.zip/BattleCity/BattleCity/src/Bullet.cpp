#include "../include/Bullet.h"

Bullet::Bullet(moveState dir, int x, int y, TankType Shooter, SDL_Renderer *renderer) : AnimatedSprite("resources/creatures/bullet.png", 20, 12, 3, renderer)
{
    srand(time(NULL));
    direction = dir;
    shooter = Shooter;
    if(direction == MoveUp)
    {
        AnimatedSprite::move(x+5, y);;
    }
    else if(direction == MoveDown)
    {
        AnimatedSprite::move(x+5, y);;
    }
    else if(direction == MoveRight)
    {
        AnimatedSprite::move(x, y+10);;
    }
    else if(direction == MoveLeft)
    {
        AnimatedSprite::move(x, y+10);;
    }
}

void Bullet::move(int dx,int dy)
{
    if (countdown < 3)
    {
        countdown--;
    }
    else if(direction == MoveUp)
    {
        AnimatedSprite::move(0, -6);
    }
    else if(direction == MoveDown)
    {
        AnimatedSprite::move(0, 6);
    }
    else if(direction == MoveRight)
    {
        AnimatedSprite::move(6, 0);
    }
    else if(direction == MoveLeft)
    {
        AnimatedSprite::move(-6, 0);
    }
}

vector<int> Bullet::unit_collision(vector<vector<Tile*> > tiles)
{
    vector<int> pos = getPos();
    int width = (int) ((pos[0]) / (40));
    int height = (int) ((pos[1])/ (40));
    //cout << width << " " << height << endl;
    if(direction == MoveRight)
    {
        if (tiles[height][width+1]->first != 'b')
        {
            vector<int> tmp;
            tmp.push_back(height);
            tmp.push_back(width+1);
            if (tiles[height][width+1]->first == 'd')
            {
                tmp.push_back(1);
            }
            else
            {
                tmp.push_back(0);
            }
            return tmp;
        }
       else if (tiles[height+1][width+1]->first != 'b')
        {
            if((double) pos[1]/40 - height > (double) 1/2)
            {
                vector<int> tmp;
                tmp.push_back(height+1);
                tmp.push_back(width+1);
                if (tiles[height+1][width+1]->first == 'd')
                {
                    tmp.push_back(1);
                }
                else
                {
                    tmp.push_back(0);
                }
                return tmp;
            }
        }
    }
    else if(direction == MoveLeft)
    {
        if (tiles[height][width]->first != 'b')
        {
            vector<int> tmp;
            tmp.push_back(height);
            tmp.push_back(width);
            if (tiles[height][width]->first == 'd')
            {
                tmp.push_back(1);
            }
            else
            {
                tmp.push_back(0);
            }
            return tmp;
        }
       else if (tiles[height+1][width]->first != 'b')
        {
            if((double) pos[1]/40 - height > (double) 1/2)
            {
                vector<int> tmp;
                tmp.push_back(height+1);
                tmp.push_back(width);
                if (tiles[height+1][width]->first == 'd')
                {
                    tmp.push_back(1);
                }
                else
                {
                    tmp.push_back(0);
                }
                return tmp;
            }
        }
    }
    else if(direction == MoveUp)
    {
        if (tiles[height][width]->first != 'b')
        {
            vector<int> tmp;
            tmp.push_back(height);
            tmp.push_back(width);
            if (tiles[height][width]->first == 'd')
            {
                tmp.push_back(1);
            }
            else
            {
                tmp.push_back(0);
            }
            return tmp;
        }
       else if (tiles[height][width+1]->first != 'b')
        {
            if((double) pos[0]/40 - width > (double) 1/2)
            {
                vector<int> tmp;
                tmp.push_back(height);
                tmp.push_back(width+1);
                if (tiles[height][width+1]->first == 'd')
                {
                    tmp.push_back(1);
                }
                else
                {
                    tmp.push_back(0);
                }
                return tmp;
            }
        }
    }
    else if(direction == MoveDown)
    {
       if (tiles[height+1][width]->first != 'b')
        {
            vector<int> tmp;
            tmp.push_back(height+1);
            tmp.push_back(width);
            if (tiles[height+1][width]->first == 'd')
            {
                tmp.push_back(1);
            }
            else
            {
                tmp.push_back(0);
            }
            return tmp;
        }
        else if (tiles[height+1][width+1]->first != 'b')
        {
            if((double) pos[0]/40 - width > (double) 1/2)
            {
                vector<int> tmp;
                tmp.push_back(height+1);
                tmp.push_back(width+1);
                if (tiles[height+1][width+1]->first == 'd')
                {
                    tmp.push_back(1);
                }
                else
                {
                    tmp.push_back(0);
                }
                return tmp;
            }
        }
    }
    vector<int> tmp;
    tmp.push_back(0);
    tmp.push_back(0);
    tmp.push_back(0);
    return tmp;
}

void Bullet::draw(SDL_Renderer * const renderer)
{
    AnimatedSprite::draw(renderer);
    if(countdown < 3)
    {
        currentRow = 4;
    }
    else if(direction == MoveUp)
    {
        currentRow = 0;
    }
    else if(direction == MoveDown)
    {
        currentRow = 2;
    }
    else if(direction == MoveRight)
    {
        currentRow = 3;
    }
    else if(direction == MoveLeft)
    {
        currentRow = 1;
    }

}

bool Bullet::hit_tank(int y, int x, TankType tenk)
{
    vector<int> pos = getPos();
    if(countdown == 3)
    {
      if(shooter != tenk)
      {
        if(direction == MoveUp)
        {
            if(abs(pos[1]-y) < 30 && abs(pos[0]-x) < 15)
            {
                return true;
            }
        }
        else if(direction == MoveDown)
        {
            if(abs(pos[1]-y) < 10 && abs(pos[0]-x) < 15)
            {
                return true;
            }
        }
        else if(direction == MoveRight)
        {
            if(abs(pos[1]-y) < 15 && abs(pos[0]-x) < 10)
            {
                return true;
            }
        }
        else if(direction == MoveLeft)
        {
            if(abs(pos[1]-y) < 15 && abs(pos[0]-x) < 30)
            {
                return true;
            }
        }
      }
    }
    return false;
}

void Bullet::destroy()
{
    countdown = 2;
}

int Bullet::getCountdown()
{
    return countdown;
}

vector<int> Bullet::getPos()
{
    vector<int> a;
    a.push_back(spriteRect.x);
    a.push_back(spriteRect.y);
    return a;
}

Bullet::~Bullet()
{

}
