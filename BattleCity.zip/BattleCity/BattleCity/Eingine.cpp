#include "Engine.h"

Engine::Engine()
{
    gameTitle = "";
}

Engine::Engine(const string &gameTitle): gameTitle(gameTitle)
{
}

void Engine::init()
{
    SDL_Init(SDL_INIT_VIDEO);
    IMG_Init(IMG_INIT_PNG);
    window = SDL_CreateWindow(gameTitle.c_str(), SDL_WINDOWPOS_UNDEFINED,
                              SDL_WINDOWPOS_UNDEFINED, 800, 640, SDL_WINDOW_RESIZABLE);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
}

bool Engine::run()
{
    //Instanciranje objekta klase AnimatedSprite.
    Tank *player = new Tank(Player,"resources/creatures/green_tank2.png",renderer);
    Tank *ai1 = new Tank(AI1,"resources/creatures/red_tank2.png",renderer);
    Tank *ai2 = new Tank(AI2,"resources/creatures/red_tank2.png",renderer);
    Tank *ai3 = new Tank(AI3,"resources/creatures/red_tank2.png",renderer);
    Tank *ai4 = new Tank(AI4,"resources/creatures/red_tank2.png",renderer);
    Sprite *health = new AnimatedSprite("resources/creatures/health.jpg", 30, 30, 0, renderer);
    Level *l = new Level("resources/levels/level1.txt", renderer);
    vector<Bullet*> bullets;
    bool taken = false;
    health->move(300,300);
    Sprite *menu = new AnimatedSprite("resources/creatures/menu.jpg", 800, 640, 0, renderer);
    Sprite *pointer = new AnimatedSprite("resources/creatures/pointer.jpg", 60, 60, 0, renderer);
    pointer->move(170,240);

    //Pretplacivanje na dogadjaje, obratiti paznju da je moguce
    //pretplatiti vise obradjivaca na isti dogadjaj.

    bool running = true;
    bool start = true;
    int choice = 0;
    SDL_Event event;
    uint32_t frameStart = 0;
    uint32_t frameEnd = 0;
    while(running) {
        frameStart = SDL_GetTicks();
        if(start)
        {
         while(SDL_PollEvent(&event)) {
            switch(event.type) {
                case SDL_QUIT:
                    running = false;
                break;
                case SDL_KEYDOWN:
                    //Prethodno resenje
                    switch(event.key.keysym.sym) {
                        case SDLK_UP:
                            if(choice == 1)
                            {
                                choice = 0;
                                pointer->move(0,-65);
                            }
                        break;
                        case SDLK_DOWN:
                            if(choice == 0)
                            {
                                choice = 1;
                                pointer->move(0,65);
                            }
                        break;
                        case SDLK_RETURN:
                            if(choice == 0)
                            {
                                start = false;
                            }
                            else
                            {
                                running = false;
                            }
                        break;

                break;
                    }
            }
        }
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);
        menu->draw(renderer);
        pointer->draw(renderer);

        }
        //SDL_PollEvent vadi dogadjaje iz reda cekanja.
        //Izmedju dva ciklusa obrade dogadjaja moze se nakupiti
        //proizvoljan broj dogadjaja stoga se pomocu while petlje
        //obradjuju svi neobradjeni dogadjaji.
        else
        {
        while(SDL_PollEvent(&event)) {
            switch(event.type) {
                case SDL_QUIT:
                    running = false;
                break;
                case SDL_KEYDOWN:
                    //Obrada dogadjaja se vrsi bez dodatnih uslova, odnosno
                    //svi obradjivaci koji su se pertplatili na dogadjaj ce ga obraditi.
                    //Prethodno resenje
                    switch(event.key.keysym.sym) {
                        case SDLK_UP:
                            player->setCurrentState(MoveUp);
                            player->move(0, -3,l->getTiles());
                        break;
                        case SDLK_DOWN:
                            player->setCurrentState(MoveDown);
                            player->move(0, 3,l->getTiles());
                        break;
                        case SDLK_LEFT:
                            player->setCurrentState(MoveLeft);
                            player->move(-3, 0,l->getTiles());
                        break;
                        case SDLK_RIGHT:
                            player->setCurrentState(MoveRight);
                            player->move(3, 0,l->getTiles());
                        break;
                        case SDLK_SPACE:
                            player->shoot();
                        break;

                break;
                    }
            }
        }
        if(player->has_shot())
        {
            vector<int> pos = player->getPos();
            Bullet *b = new Bullet(player->getCurrentState(),pos.at(0),pos.at(1),player->getType(),renderer);
            bullets.push_back(b);
        }
        if(ai1->has_shot() && ai1->getHealth()>0)
        {
            vector<int> pos = ai1->getPos();
            Bullet *b = new Bullet(ai1->getCurrentState(),pos.at(0),pos.at(1),ai1->getType(),renderer);
            bullets.push_back(b);
        }
        if(ai2->has_shot() && ai2->getHealth()>0)
        {
            vector<int> pos = ai2->getPos();
            Bullet *b = new Bullet(ai2->getCurrentState(),pos.at(0),pos.at(1),ai2->getType(),renderer);
            bullets.push_back(b);
        }
        if(ai3->has_shot() && ai3->getHealth()>0)
        {
            vector<int> pos = ai3->getPos();
            Bullet *b = new Bullet(ai3->getCurrentState(),pos.at(0),pos.at(1),ai3->getType(),renderer);
            bullets.push_back(b);
        }
        if(ai4->has_shot() && ai4->getHealth()>0)
        {
            vector<int> pos = ai4->getPos();
            Bullet *b = new Bullet(ai4->getCurrentState(),pos.at(0),pos.at(1),ai4->getType(),renderer);
            bullets.push_back(b);
        }
        for(int i=bullets.size()-1;i>=0;i--)
        {
            if(bullets.at(i)->getCountdown() == 3)
            {
                vector<int> check = bullets.at(i)->unit_collision(l->getTiles());
                if(check.at(0) != 0 || check.at(1) != 0)
                {
                    bullets.at(i)->destroy();
                    if(check.at(2) == 1)
                    {
                        l->changeTile(check.at(0),check.at(1),'b');
                    }
                }
                vector<int> playerPos = player->getPos();
                if(bullets[i]->hit_tank(playerPos[1],playerPos[0],player->getType()))
                {
                    player->damage();
                    bullets[i]->destroy();
                }
                vector<int> ai1Pos = ai1->getPos();
                if(bullets.at(i)->hit_tank(ai1Pos[1],ai1Pos[0],ai1->getType()) && ai1->getHealth() > 0)
                {
                    ai1->damage();
                    bullets.at(i)->destroy();
                }
                vector<int> ai2Pos = ai2->getPos();
                if(bullets.at(i)->hit_tank(ai2Pos[1],ai2Pos[0],ai2->getType()) && ai2->getHealth() > 0)
                {
                    ai2->damage();
                    bullets.at(i)->destroy();
                }
                vector<int> ai3Pos = ai3->getPos();
                if(bullets.at(i)->hit_tank(ai3Pos[1],ai3Pos[0],ai3->getType()) && ai3->getHealth() > 0)
                {
                    ai3->damage();
                    bullets.at(i)->destroy();
                }
                vector<int> ai4Pos = ai4->getPos();
                if(bullets.at(i)->hit_tank(ai4Pos[1],ai4Pos[0],ai4->getType()) && ai4->getHealth() > 0)
                {
                    ai4->damage();
                    bullets.at(i)->destroy();
                }
            }
            else if(bullets.at(i)->getCountdown() == 0)
            {
                bullets.erase(bullets.begin()+i);
            }
        }


        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);

        //Iscrtavanje sprite-a.
        l->draw(renderer);
        vector<int> pos = player->getPos();
        if(!taken)
        {
            health->draw(renderer);
        }
        if(!taken && abs(pos[0]-300) < 33 && abs(pos[1]-300) < 33)
        {
            taken = true;
            player->shield();
        }
        if(ai1->getHealth() > 0)
        {
           ai1->AI_think(l->getTiles(),player->getPos());
           ai1->draw(renderer);
        }
        if(ai2->getHealth() > 0)
        {
           ai2->AI_think(l->getTiles(),player->getPos());
           ai2->draw(renderer);
        }
        if(ai3->getHealth() > 0)
        {
           ai3->AI_think(l->getTiles(),player->getPos());
           ai3->draw(renderer);
        }
        if(ai4->getHealth() > 0)
        {
           ai4->AI_think(l->getTiles(),player->getPos());
           ai4->move(0,0,l->getTiles());
           ai4->draw(renderer);
        }
        player->draw(renderer);
        player->move(0,0,l->getTiles());
        for(Bullet *b:bullets)
        {
            b->move(0,0);
            b->draw(renderer);
        }
        if(player->getHealth() <= 0)
        {
            start = true;
            choice = 0;
            player = new Tank(Player,"resources/creatures/green_tank2.png",renderer);
            ai1 = new Tank(AI1,"resources/creatures/red_tank2.png",renderer);
            ai2 = new Tank(AI2,"resources/creatures/red_tank2.png",renderer);
            ai3 = new Tank(AI3,"resources/creatures/red_tank2.png",renderer);
            ai4 = new Tank(AI4,"resources/creatures/red_tank2.png",renderer);
            health = new AnimatedSprite("resources/creatures/health.jpg", 30, 30, 0, renderer);
            l = new Level("resources/levels/level1.txt", renderer);
            bullets.clear();
            taken = false;
            health->move(300,300);
            Sprite *menu = new AnimatedSprite("resources/creatures/menu.jpg", 1044, 501, 0, renderer);
            Sprite *pointer = new AnimatedSprite("resources/creatures/pointer.jpg", 60, 60, 0, renderer);
            pointer->move(300,300);
        }
        }
        SDL_RenderPresent(renderer);

        frameEnd = SDL_GetTicks();

        //Ogranicavanje brzine iscrtavanja na frameRateCap FPS.
        if(frameEnd - frameStart < frameRateCap) {
            SDL_Delay(frameRateCap - (frameEnd - frameStart));
        }
    }

    return true;
}

Engine::~Engine()
{
    //Destruktor klase engine oslobadja sve resurse
    //koji su prethodno zauzeti.
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
}
